package com.test.abid.testapp;

/**
 * Created by MuhammadAbid on 9/28/2016.
 */
public interface OnAddItemListner {
    public void onItemAdd(Person person);
}
