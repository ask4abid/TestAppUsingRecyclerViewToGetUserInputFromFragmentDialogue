package com.test.abid.testapp;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * Created by MuhammadAbid on 9/28/2016.
 */
//The adapters View Holder
public class View_Holder extends RecyclerView.ViewHolder {


    TextView personName;

    View_Holder(View itemView) {
        super(itemView);
        personName = (TextView) itemView.findViewById(R.id.rowTextViewName);
    }

}
