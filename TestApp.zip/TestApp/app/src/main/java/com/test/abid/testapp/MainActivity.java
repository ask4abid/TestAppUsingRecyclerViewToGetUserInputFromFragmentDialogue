package com.test.abid.testapp;
import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by MuhammadAbid on 9/28/2016.
 */
public class MainActivity extends Activity implements OnAddItemListner {
    final Context context = this;
    Toolbar mActionBarToolbar;
    private ArrayList<Person> list;
    RecyclerView recyclerView;
    private Recycler_View_Adapter adapter;
    Person person;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connectView();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(fabClickListener);
    }

    private void ShowDialogueFragment() {
        FragmentManager fm = getFragmentManager();
        MyPersonDialogFragment dialogFragment = new MyPersonDialogFragment(this);
        dialogFragment.show(fm, "Sample Fragment");
    }

    /// dummy data was tested as it is coming from JSON API
    private ArrayList<Person> fill_with_data() {
        ArrayList<Person> data = new ArrayList<>();
        data.add(new Person("BatMan","Hello" ));
        data.add(new Person("Ceo","MicroSoft"));
        data.add(new Person("Muhammad", "Abid"));
        data.add(new Person("whats app" , "Mark"));
        return data;

    }

    private void connectView() {
        mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar);
        mActionBarToolbar.setTitleTextColor(getResources().getColor(R.color.textColorPrimaryWhite));
        mActionBarToolbar.setTitle("Names Activity");
        list = new ArrayList<Person>();
        list = fill_with_data();
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(false);
        LinearLayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new Recycler_View_Adapter(list, this);
        recyclerView.setAdapter(adapter);
    }

    private View.OnClickListener fabClickListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ShowDialogueFragment();
        }
    };

    @Override
    public void onItemAdd(Person person) {
        list.add(person);
        adapter.notifyDataSetChanged();
    }
}
