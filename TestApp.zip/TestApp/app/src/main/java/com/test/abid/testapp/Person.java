package com.test.abid.testapp;

/**
 * Created by MuhammadAbid on 9/28/2016.
 */
public class Person {

    private String personFName;
    private String personLName;

    public Person(String personFName, String personLName) {
        this.personFName = personFName;
        this.personLName = personLName;
    }
    public String getPersonFName() {
        return personFName;
    }

    public void setPersonFName(String personFName) {
        this.personFName = personFName;
    }

    public String getPersonLName() {
        return personLName;
    }

    public void setPersonLName(String personLName) {
        this.personLName = personLName;
    }




}

