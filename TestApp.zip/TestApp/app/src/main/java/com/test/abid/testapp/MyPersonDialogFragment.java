package com.test.abid.testapp;

import android.app.DialogFragment;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by MuhammadAbid on 9/28/2016.
 */
public class MyPersonDialogFragment extends DialogFragment {

     EditText userInputFname;
     EditText userInputLname;
     OnAddItemListner onAddItemListner ;

    public MyPersonDialogFragment() {
     }

    public MyPersonDialogFragment(OnAddItemListner onAddItemListner) {
        this.onAddItemListner = onAddItemListner;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.prompt_to_get_name, container, false);
        getDialog().setTitle("Add Name");
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        userInputFname = (EditText)view.findViewById(R.id.editTextDialogUserInputFname);
        userInputLname = (EditText)view.findViewById(R.id.editTextDialogUserInputLname);

        Button addBtn = (Button) view.findViewById(R.id.addButton);
        Button  cancelBtn = (Button) view.findViewById(R.id.cancelButton);

        addBtn.setOnClickListener(addClickListner);
        cancelBtn.setOnClickListener(cancelClickListner);


    }

    private View.OnClickListener addClickListner=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Person person;

            String firstInput = userInputFname.getText().toString();
            String secondInput = userInputLname.getText().toString();

            if(firstInput.isEmpty() || secondInput.isEmpty()){
                Toast.makeText(getActivity(), "Both values are required: ", Toast.LENGTH_SHORT).show();
                return;

            }
            person= new Person(firstInput.substring(0,1).toUpperCase()+firstInput.substring(1),
                    secondInput.substring(0, 1).toUpperCase()+secondInput.substring(1));
                    onAddItemListner.onItemAdd(person);

            dismiss();
        }
    };

    private View.OnClickListener cancelClickListner =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
        dismiss();
        }
    };

}
